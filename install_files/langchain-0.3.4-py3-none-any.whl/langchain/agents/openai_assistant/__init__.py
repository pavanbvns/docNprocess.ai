from langchain.agents.openai_assistant.base import OpenAIAssistantRunnable

__all__ = ["OpenAIAssistantRunnable"]
