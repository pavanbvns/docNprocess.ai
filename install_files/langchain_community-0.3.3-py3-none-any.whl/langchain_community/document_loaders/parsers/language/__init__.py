from langchain_community.document_loaders.parsers.language.language_parser import (
    LanguageParser,
)

__all__ = ["LanguageParser"]
